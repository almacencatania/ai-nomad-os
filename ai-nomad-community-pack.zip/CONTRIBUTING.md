# 🤝 CONTRIBUTING / KÖZREMŰKÖDÉS

## 🇭🇺 Magyar verzió

Ez a projekt az **AI Nomad OS** elveire épül:  
👉 egyszerűség  
👉 újrahasznosíthatóság  
👉 remix kultúra  
👉 értékteremtés zaj nélkül  

### Alapelvek
- Ne bonyolítsd túl.
- Ha fejlesztesz → dokumentálj.
- Ha módosítasz → oszd vissza.
- Ha forkolod → nevezd meg a forrást.

### Remix kultúra
Ez a projekt arra épül, hogy:
- mások **másolják**
- átalakítsák
- továbbfejlesszék
- saját terméket építsenek belőle

Ez nem hiba. Ez a cél.

---

## 🇺🇸 English version

This project follows the **AI Nomad OS philosophy**:
👉 simplicity  
👉 reusability  
👉 remix culture  
👉 real value creation  

### Core principles
- Don’t overcomplicate.
- If you build → document it.
- If you improve → share it back.
- If you fork → give credit.

### Remix culture
This project is designed to be:
- copied  
- remixed  
- extended  
- used as foundation for real products  

This is not a bug. This is the system.
