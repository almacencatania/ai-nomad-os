# Security Policy

This is an early-stage open project.

If you find a vulnerability:
- Do not exploit it.
- Do not publish it publicly.
- Open a GitHub Issue instead.

Goal: keep the system usable for everyone.
