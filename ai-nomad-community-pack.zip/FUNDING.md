# Funding & Support

This project is open and free.

If you want to support it:
- Star the repo ⭐
- Share it
- Build something with it
- Credit the source

No mandatory donations.  
Value comes first.
