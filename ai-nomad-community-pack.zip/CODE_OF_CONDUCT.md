# Code of Conduct

This project follows one simple rule:

> Be constructive or leave.

No drama.  
No ego battles.  
No manipulation.  
No bullshit.

We build useful things here.
