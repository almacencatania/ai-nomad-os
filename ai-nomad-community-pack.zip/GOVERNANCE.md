# Project Governance

This project is maintained by the creator and the community.

There is no hierarchy.  
There is no bureaucracy.  
There is only contribution quality.

Good ideas win.  
Clean solutions win.  
Useful work wins.
