# NotebookLM Prompt Pack

## Blueprint
"Generate structured blueprint with FRICTION, GAP, ENGINE, PROFIT, REMIX"

## Documentation
"Generate clean README and docs from sources"
