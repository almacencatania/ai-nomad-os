# 📰 Substack szerepe

Substack = kirakat + terjesztés.

## Használat
- Blueprint → cikk
- Repo link → hitelesség
- Notion link → remixelhetőség

Nem marketing blog.
Publikus termékfeed.
