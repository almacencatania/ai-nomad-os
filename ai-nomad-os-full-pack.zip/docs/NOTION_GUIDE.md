# 🧠 Notion szerepe

Notion = Product OS

## Struktúra
- 00_INDEX → dashboard
- 10_LAB → kutatás
- 20_BLUEPRINTS → termék sablonok
- 30_PUBLISH → kész tartalom

## Elv
Notion nem jegyzetelésre.
Notion termék-archívum.
