# 🚀 AI Nomad OS – Quick Setup Guide
Rövid, végrehajtható induló útmutató.

## Cél
30 percen belül működjön:
- NotebookLM (LAB)
- Notion struktúra (PROD)
- GitHub repo (BUILD)
- Substack draft (PUBLISH)

## Minimális lépések
1. NotebookLM → új notebook: `[META] AI_Nomad_System`
2. Források: README + saját jegyzet + guide
3. Prompt:
   "Based only on uploaded sources generate blueprint with FRICTION, GAP, ENGINE, PROFIT, REMIX in Markdown."
4. Notion → 4 oldal:
   - 00_INDEX
   - 10_LAB
   - 20_BLUEPRINTS
   - 30_PUBLISH
5. Substack → első draft elkészítve
