# 📘 NotebookLM használat – AI Nomad OS

## Mire való?
- Kutatás
- Blueprint generálás
- Dokumentáció sűrítés
- Több forrásból egy rendszer készítése

## Mikor használd?
✔ ha több forrásod van  
✔ ha struktúrát akarsz  
✘ gyors ötleteléshez ne

## Kötelező prompt minta
"Based only on the uploaded sources, generate a structured blueprint in Markdown."
