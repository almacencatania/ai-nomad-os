# 🚀 AI Nomad Starter Kit

> Build digital products with $0 monthly cost (free tiers first)

A minimal, remix-ready operating system for solo builders using NotebookLM, Notion, GitHub, and Substack.

## 📖 What is this?

AI Nomad OS workflow:
- ✅ Research & distill (NotebookLM)
- ✅ Organize & track (Notion)
- ✅ Package & version (GitHub)
- ✅ Publish & distribute (Substack)
- ✅ Optional: Deploy apps (Cloud Run / Vercel)

**Goal:** 1-click remixable assets (Duplicate / Fork).

---

## 🛠️ Stack (Free-first)

| Tool | Purpose | Cost |
|------|---------|------|
| **NotebookLM** | Source-grounded research lab | FREE tier |
| **Notion** | Product OS + tracker | FREE (Personal) |
| **GitHub** | Version control + template repos | FREE |
| **Substack** | Publishing + audience | FREE |
| **Cloud Run** | Optional deployment | FREE tier (limits apply) |
| **Gemini** | Fast AI engine | FREE tier (limits apply) |

> Note: Free tiers have quotas/limits. Treat "$0" as a target, not a promise.

---

## 🚀 Quick Start (15 minutes)

### Prerequisites
- Google Account (NotebookLM / Gemini / optional Cloud Run)
- Notion Account
- GitHub Account
- Substack Account (optional for first run)

### 1) Duplicate the Notion workspace
Use: `templates/notion/WORKSPACE_STRUCTURE.md` + `templates/notion/TRACKER_SETUP.md`

### 2) Create a NotebookLM notebook
Name it: `[META] AI_Nomad_System_v1`  
Use prompts: `templates/notebooklm/RESEARCH_PROMPTS.md`

### 3) Generate your first blueprint
Paste the LIGHT prompt (in prompts file) into NotebookLM chat → export Markdown.

### 4) Save in Notion + set scores
Add to Notion tracker and paste the blueprint into the project page.

### 5) Publish (optional)
Use Substack templates: `templates/substack/LAUNCH_POST_TEMPLATE.md` and `TUTORIAL_POST_TEMPLATE.md`

---

## 📂 Repository Structure

- `docs/` — setup + tool guides
- `templates/` — Notion / NotebookLM / Substack templates
- `scripts/` — optional helpers
- `examples/` — sample projects and packaging patterns

---

## 📚 Docs
- `docs/SETUP_GUIDE.md`
- `docs/NOTEBOOKLM_GUIDE.md`
- `docs/NOTION_GUIDE.md`
- `docs/SUBSTACK_GUIDE.md`

---

## 📜 License
MIT — see `LICENSE`.

