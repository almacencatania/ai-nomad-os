# [PROJECT: _____________]

**Created:** [Date]
**Status:** Idea / Draft / Built / Published
**Category:** Micro-SaaS / Digital Product / Template Pack / Automation

---

## 1) FRICTION
- Who wastes time/money?
- What is the current workflow?

## 2) GAP
- Why is the cheap AI version missing?
- What changed recently that makes it possible?

## 3) ENGINE (No-code / Vibe-code / Sales-code)
- No-code:
- Vibe-code:
- Sales-code:

## 4) PROFIT (≤30 days)
- Offer:
- Price:
- Distribution:

## 5) REMIX ROUTE (1-click)
- Notion duplicate:
- GitHub template (optional):
