# Blueprint Tracker — Setup (Notion)

Create a database with these fields:

FIELD	TYPE	DEFAULT
Name	Text	-
Status	Select	Idea (Idea/Draft/Built/Published)
Category	Select	LAB (LAB/PROD/BUILD/SALES)
Engine	Multi-select	NotebookLM, Notion
ProfitPath	Select	Substack (Substack/Stripe/Gumroad/Lemon/Affiliate)
RemixLink	URL	-
EffortMin	Number	30
CostCap	Number	5
ProfitScore	Number	3
RemixScore	Number	3
NextAction	Text	-

Template inside each project page:
- Paste blueprint at top
- Links section: Demo/GitHub/Notion/Substack
