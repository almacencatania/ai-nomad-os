# Notion Workspace Structure (AI Nomad OS)

Create 4 top-level pages:

1) `00_INDEX`
- Today (3 bullets)
- Links: NotebookLM / Notion Tracker / GitHub / Substack
- Rules: "Need-to-know, no extra tools"

2) `10_LAB`
- Paste NotebookLM exports here
- Optional: tag each page with `[PROJECT] name`

3) `20_BLUEPRINTS`
- Create a database: "Blueprint Tracker"
- Each row = one product/asset/project
- Each row opens a page: store blueprint + links

4) `30_PUBLISH`
- Drafts (Substack)
- Release notes
- Public links list
