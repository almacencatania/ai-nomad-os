# NotebookLM Prompt Pack (AI Nomad OS)

## 1) LIGHT Blueprint (fast)
```text
Készíts 1 db “Product Blueprint”-et a források alapján.
Szabály: tőmondatok, mezőnként max 10 sor, semmi magyarázat.

1) FRICTION
2) GAP
3) ENGINE (No-code / Vibe-code / Sales-code)
4) PROFIT (≤30 nap)
5) REMIX ROUTE (1-click)
```

## 2) Tutorial Draft (Substack-ready)
```text
Írj egy Substack tutorial poszt vázlatot a források alapján.
Sorrend:
1) Hook (3 sor)
2) What it is (5 sor)
3) 15-minute checklist (bullet)
4) Template (Markdown)
5) Remix links placeholders
6) CTA (Duplicate/Fork/Share)
Szabály: rövid, végrehajtható, semmi marketing trükk.
```

## 3) Code Recipe (only if unavoidable)
```text
Ha szükséges kód:
- Adj minimal multi-file struktúrát
- Minden fájl rövid
- Futási lépések (3–6 sor)
Ha nem szükséges: adj No-code alternatívát.
```
