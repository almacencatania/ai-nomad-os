#!/usr/bin/env bash
set -e

echo "AI Nomad Starter Kit - dependency check"
command -v git >/dev/null 2>&1 && echo "OK: git" || echo "WARN: git not found (optional if using web upload)"
command -v python >/dev/null 2>&1 && echo "OK: python" || echo "WARN: python not found (optional)"
echo "Done."
