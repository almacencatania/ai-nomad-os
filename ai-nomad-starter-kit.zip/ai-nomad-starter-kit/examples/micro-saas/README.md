# Example: Micro-SaaS Skeleton (minimal)

This is a tiny example to show where code lives when you *must* have code.

- `main.py` exposes a minimal HTTP server.
- `Dockerfile` is ready for Cloud Run (optional).
