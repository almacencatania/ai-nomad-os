# 📰 Substack Guide (AI Nomad OS)

Substack = **PUBLISH layer** (tutorial + distribution).
Not consulting. Focus: digital products, templates, tools.

---

## Post types
- Tutorial post (process + remix links)
- Launch post (what it is + how to get it)

Templates:
- `templates/substack/TUTORIAL_POST_TEMPLATE.md`
- `templates/substack/LAUNCH_POST_TEMPLATE.md`

---

## Mandatory block order
1) Hook (pain / time waste)
2) What you built (product/tool/template)
3) 15-minute checklist
4) Remix links (Notion Duplicate / GitHub Fork)
5) CTA (Duplicate/Fork/Share)

---

## Code
- If short: Substack code block is enough
- If multi-file or deploy: move to GitHub and link it
