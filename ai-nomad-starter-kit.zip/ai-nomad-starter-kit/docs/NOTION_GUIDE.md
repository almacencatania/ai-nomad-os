# 🧠 Notion Guide (AI Nomad OS)

Notion = **PROD OS** (structure + tracker + asset library).

---

## Minimal workspace (4 pages)
- `00_INDEX` — dashboard + rules + today
- `10_LAB` — NotebookLM exports (raw distills)
- `20_BLUEPRINTS` — tracker DB + project pages
- `30_PUBLISH` — drafts + links + release notes

Use: `templates/notion/WORKSPACE_STRUCTURE.md`

---

## Tracker DB
Use: `templates/notion/TRACKER_SETUP.md`

### Scoring (simple)
- ProfitScore 1–5 (or ValueScore if nonprofit)
- RemixScore 1–5 (how copyable)

---

## Public vs private
- Private: everything by default
- Public: only the **Template** page(s) you want people to duplicate
- Link your public template in Substack posts
