# 📘 NotebookLM Guide (AI Nomad OS)

NotebookLM = **source-grounded LAB**.
Use it to distill sources into remixable assets (blueprints, checklists, posts).

---

## When to use NotebookLM
✅ Use for:
- multi-source distillation
- technical docs condensation
- blueprint generation
- FAQ / tutorial drafts

❌ Avoid for:
- version control
- public distribution
- long-term structured project tracking

---

## Naming convention
- `[META]` system knowledge
- `[PROJECT]` specific build
- `[STACK]` platform docs
- `[MARKET]` competitive research

---

## Prompt pack
See: `templates/notebooklm/RESEARCH_PROMPTS.md`

---

## Export
- Copy output as Markdown
- Store:
  - Notion: `10_LAB` or inside a project page
  - GitHub: `docs/` or `templates/`
  - Substack: tutorial post draft
