# 🚀 AI Nomad OS — Setup Guide (0 → 1)

**Goal:** Get a working LAB → PROD → PUBLISH pipeline with minimal setup.

**Time:** 30–45 minutes first time  
**Rule:** No extra tooling unless unavoidable.

---

## Phase 1 — Accounts (5 min)
- Google (NotebookLM)
- Notion
- GitHub
- Substack (optional for day 1)

---

## Phase 2 — NotebookLM (10 min)
### 1) Create notebook
Name: `[META] AI_Nomad_System_v1`

### 2) Add sources (5–15)
Prefix each source title:
- `[STRAT] ...`
- `[STACK] ...`
- `[REMIX] ...`
- `[PUBLISH] ...`

### 3) Generate first blueprint (LIGHT)
Paste this into NotebookLM chat:

```text
Készíts 1 db “Product Blueprint”-et a források alapján.
Szabály: tőmondatok, mezőnként max 10 sor, semmi magyarázat.

1) FRICTION
2) GAP
3) ENGINE (No-code / Vibe-code / Sales-code)
4) PROFIT (≤30 nap)
5) REMIX ROUTE (1-click)
```

Export/copy the Markdown.

---

## Phase 3 — Notion (15 min)
### 1) Create workspace structure
Follow: `templates/notion/WORKSPACE_STRUCTURE.md`

### 2) Create the tracker DB
Follow: `templates/notion/TRACKER_SETUP.md`

### 3) Add the first project
- New row in tracker
- Paste NotebookLM blueprint into the project page body

---

## Phase 4 — GitHub (10 min)
### Option A: Upload ZIP (fast)
- Create new repo: `ai-nomad-starter-kit`
- Upload all files from this folder (or upload the ZIP contents)

### Option B: Git (clean)
```bash
git init
git add .
git commit -m "Initial commit: AI Nomad Starter Kit"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ai-nomad-starter-kit.git
git push -u origin main
```

---

## Phase 5 — Substack (optional, 5 min)
- Create a publication
- Draft a post using: `templates/substack/TUTORIAL_POST_TEMPLATE.md`
- Include Remix links: Notion duplicate + GitHub repo

---

## ✅ 15-minute repeatable loop (per project)
1) NotebookLM distill → 1 blueprint  
2) Notion store + score  
3) Publish tutorial (optional)  
4) Remix link (Notion duplicate / GitHub template)

